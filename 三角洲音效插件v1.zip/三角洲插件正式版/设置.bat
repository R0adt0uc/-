@echo off
chcp 65001 >nul
cd /d "%~dp0"
"%~dp0启动程序.exe" --settings
pause
